
/*
  INSTRUKSI MENJALANKAN BACKEND:
  1. Pastikan Node.js dan MySQL sudah terinstall.
  2. Buat folder baru terpisah atau gunakan terminal di root project.
  3. Install dependencies:
     npm install express mysql2 cors body-parser
  4. Buat database MySQL menggunakan file schema.sql.
  5. Sesuaikan konfigurasi dbConfig di bawah ini.
  6. Jalankan server: node backend/server.js
*/

const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
const PORT = 5000;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Konfigurasi Database
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',      // Ganti dengan user MySQL Anda
    password: '',      // Ganti dengan password MySQL Anda
    database: 'vinixport_db'
});

db.connect(err => {
    if (err) {
        console.error('Error connecting to MySQL:', err);
        return;
    }
    console.log('Connected to MySQL Database');
});

// Helper to map DB snake_case to frontend camelCase
const mapUserToFrontend = (dbUser) => {
    if (!dbUser) return null;
    return {
        id: dbUser.id,
        name: dbUser.name,
        email: dbUser.email,
        // Map avatar_url to avatarUrl
        avatarUrl: dbUser.avatar_url || '', 
        title: dbUser.title || '',
        bio: dbUser.bio || ''
    };
};

const mapProjectToFrontend = (dbProject) => {
    return {
        ...dbProject,
        imageUrl: dbProject.image_url,
        tags: dbProject.tags ? dbProject.tags.split(',') : []
    };
};

const mapCertToFrontend = (dbCert) => {
    return {
        ...dbCert,
        imageUrl: dbCert.image_url,
        date: dbCert.date_issued
    };
};


// --- ROUTES ---

// 1. Register
app.post('/api/register', (req, res) => {
    const { name, email, password } = req.body;
    const sql = 'INSERT INTO users (name, email, password) VALUES (?, ?, ?)';
    db.query(sql, [name, email, password], (err, result) => {
        if (err) {
            if (err.code === 'ER_DUP_ENTRY') {
                return res.status(400).json({ message: 'Email already exists' });
            }
            return res.status(500).json({ error: err.message });
        }
        res.status(201).json({ message: 'User registered successfully' });
    });
});

// 2. Login
app.post('/api/login', (req, res) => {
    const { email, password } = req.body;
    const sql = 'SELECT * FROM users WHERE email = ? AND password = ?';
    db.query(sql, [email, password], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        if (results.length === 0) return res.status(401).json({ message: 'Invalid credentials' });
        
        const rawUser = results[0];
        const user = mapUserToFrontend(rawUser);
        
        res.json({ user });
    });
});

// 3. Update User Profile
app.put('/api/users/:id', (req, res) => {
    const userId = req.params.id;
    const { title, bio, avatarUrl } = req.body;
    
    // Build dynamic query
    let fields = [];
    let values = [];
    if (title !== undefined) { fields.push('title = ?'); values.push(title); }
    if (bio !== undefined) { fields.push('bio = ?'); values.push(bio); }
    if (avatarUrl !== undefined) { fields.push('avatar_url = ?'); values.push(avatarUrl); }
    
    if (fields.length === 0) return res.json({ message: 'No changes' });
    
    values.push(userId);
    const sql = `UPDATE users SET ${fields.join(', ')} WHERE id = ?`;
    
    db.query(sql, values, (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: 'Profile updated' });
    });
});

// 4. Get Portfolio Data (Projects & Certs)
app.get('/api/portfolio/:userId', (req, res) => {
    const userId = req.params.userId;
    
    const sqlProjects = 'SELECT * FROM projects WHERE user_id = ? ORDER BY created_at DESC';
    const sqlCerts = 'SELECT * FROM certificates WHERE user_id = ? ORDER BY created_at DESC';

    db.query(sqlProjects, [userId], (err, projects) => {
        if (err) return res.status(500).json({ error: err.message });
        
        db.query(sqlCerts, [userId], (err, certs) => {
            if (err) return res.status(500).json({ error: err.message });
            
            res.json({
                projects: projects.map(mapProjectToFrontend),
                certificates: certs.map(mapCertToFrontend)
            });
        });
    });
});

// 5. Add Project
app.post('/api/projects', (req, res) => {
    const { userId, title, description, imageUrl, link, tags } = req.body;
    const tagsString = Array.isArray(tags) ? tags.join(',') : tags;
    const sql = 'INSERT INTO projects (user_id, title, description, image_url, link, tags) VALUES (?, ?, ?, ?, ?, ?)';
    
    db.query(sql, [userId, title, description, imageUrl, link, tagsString], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        
        // Return the created object with ID
        const newProject = {
            id: result.insertId,
            user_id: userId,
            title, 
            description, 
            imageUrl, 
            link, 
            tags: Array.isArray(tags) ? tags : []
        };
        res.status(201).json(newProject);
    });
});

// 6. Delete Project
app.delete('/api/projects/:id', (req, res) => {
    const sql = 'DELETE FROM projects WHERE id = ?';
    db.query(sql, [req.params.id], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: 'Project deleted' });
    });
});

// 7. Add Certificate
app.post('/api/certificates', (req, res) => {
    const { userId, title, issuer, date, imageUrl } = req.body;
    const sql = 'INSERT INTO certificates (user_id, title, issuer, date_issued, image_url) VALUES (?, ?, ?, ?, ?)';
    
    db.query(sql, [userId, title, issuer, date, imageUrl], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        
        const newCert = {
            id: result.insertId,
            user_id: userId,
            title,
            issuer,
            date,
            imageUrl
        };
        res.status(201).json(newCert);
    });
});

// 8. Delete Certificate
app.delete('/api/certificates/:id', (req, res) => {
    const sql = 'DELETE FROM certificates WHERE id = ?';
    db.query(sql, [req.params.id], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: 'Certificate deleted' });
    });
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
