
import React, { useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { usePortfolio } from '../contexts/PortfolioContext';

type UploadType = 'project' | 'certificate';

const UploadPage: React.FC = () => {
    const [file, setFile] = useState<File | null>(null);
    const [isDragging, setIsDragging] = useState(false);
    const [uploadType, setUploadType] = useState<UploadType>('project');
    
    // Shared field
    const [title, setTitle] = useState('');

    // Project fields
    const [description, setDescription] = useState('');
    const [link, setLink] = useState('');
    const [tags, setTags] = useState('');

    // Certificate fields
    const [issuer, setIssuer] = useState('');
    const [date, setDate] = useState('');

    const [uploadStatus, setUploadStatus] = useState('');
    const navigate = useNavigate();
    const { addProject, addCertificate } = usePortfolio();

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            setFile(e.target.files[0]);
        }
    };

    const handleDragEnter = (e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDragging(true);
    };

    const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDragging(false);
    };

    const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
    };

    const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDragging(false);
        if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
            setFile(e.dataTransfer.files[0]);
            e.dataTransfer.clearData();
        }
    }, []);

    const convertToBase64 = (file: File): Promise<string> => {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = () => resolve(reader.result as string);
            reader.onerror = error => reject(error);
        });
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!file) {
            setUploadStatus('Please select an image or file to upload.');
            return;
        }
        setUploadStatus('Uploading...');

        try {
            // Convert file to Base64 string for persistence in Mock LocalStorage
            // In a real app, you would upload 'file' to a server (S3/Cloudinary) and get a URL.
            const imageUrl = await convertToBase64(file);

            if (uploadType === 'project') {
                 addProject({
                    title,
                    description,
                    imageUrl,
                    link,
                    tags: tags.split(',').map(tag => tag.trim()).filter(Boolean),
                });
            } else {
                addCertificate({
                    title,
                    issuer,
                    date,
                    imageUrl,
                });
            }

            setUploadStatus(`Successfully uploaded ${uploadType}: ${title}! Redirecting...`);
            
            setTimeout(() => {
                navigate('/portfolio');
            }, 1500);
        } catch (error) {
            setUploadStatus('Error processing image. Please try again.');
            console.error(error);
        }
    };
    
    return (
        <div className="container mx-auto p-4 md:p-8">
            <div className="max-w-3xl mx-auto bg-white dark:bg-gray-800 shadow-xl rounded-lg p-8">
                <h1 className="text-3xl font-bold mb-2 text-center text-gray-900 dark:text-white">Upload Content</h1>
                <p className="text-center text-gray-500 dark:text-gray-400 mb-6">Choose what you want to add to your portfolio.</p>
                
                <form onSubmit={handleSubmit} className="space-y-6">
                    <div>
                        <label className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Content Type</label>
                        <div className="flex rounded-md shadow-sm">
                            <button
                                type="button"
                                onClick={() => setUploadType('project')}
                                className={`px-4 py-2 block w-full text-sm font-medium rounded-l-lg border border-gray-200 dark:border-gray-600 ${uploadType === 'project' ? 'bg-blue-600 text-white' : 'bg-white dark:bg-gray-700 text-gray-900 dark:text-white hover:bg-gray-50'}`}
                            >
                                Project
                            </button>
                            <button
                                type="button"
                                onClick={() => setUploadType('certificate')}
                                className={`px-4 py-2 block w-full text-sm font-medium rounded-r-lg border-t border-b border-r border-gray-200 dark:border-gray-600 ${uploadType === 'certificate' ? 'bg-blue-600 text-white' : 'bg-white dark:bg-gray-700 text-gray-900 dark:text-white hover:bg-gray-50'}`}
                            >
                                Certificate
                            </button>
                        </div>
                    </div>

                    <div>
                        <label className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                            {uploadType === 'project' ? 'Project Image' : 'Certificate File'}
                        </label>
                        <div
                            onDragEnter={handleDragEnter}
                            onDragLeave={handleDragLeave}
                            onDragOver={handleDragOver}
                            onDrop={handleDrop}
                            className={`flex justify-center items-center w-full h-64 px-4 transition bg-white dark:bg-gray-700 border-2 border-gray-300 dark:border-gray-600 border-dashed rounded-md appearance-none hover:border-gray-400 focus:outline-none ${isDragging ? 'border-blue-500' : ''}`}
                        >
                             <label htmlFor="file-upload" className="w-full h-full flex flex-col justify-center items-center cursor-pointer">
                                <input id="file-upload" type="file" className="hidden" onChange={handleFileChange} accept="image/*" />
                                <div className="text-center">
                                    <svg className="mx-auto h-12 w-12 text-gray-400" stroke="currentColor" fill="none" viewBox="0 0 48 48" aria-hidden="true">
                                        <path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                    </svg>
                                    {file ? (
                                        <p className="mt-1 text-sm text-gray-600 dark:text-gray-300">
                                            <span className="font-semibold">{file.name}</span>
                                        </p>
                                    ) : (
                                        <p className="mt-1 text-sm text-gray-600 dark:text-gray-300">
                                            <span className="font-semibold">Drag and drop</span> or <span className="text-blue-500">click to upload</span>
                                        </p>
                                    )}
                                </div>
                            </label>
                        </div>
                    </div>
                    
                    {uploadType === 'project' ? (
                        <>
                            <div>
                                <label htmlFor="title" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Project Title</label>
                                <input type="text" id="title" value={title} onChange={e => setTitle(e.target.value)} className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white" required />
                            </div>
                            <div>
                                <label htmlFor="description" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Description</label>
                                <textarea id="description" rows={4} value={description} onChange={e => setDescription(e.target.value)} className="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white" required></textarea>
                            </div>
                             <div>
                                <label htmlFor="link" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Project Link</label>
                                <input type="url" id="link" value={link} onChange={e => setLink(e.target.value)} className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white" placeholder="https://example.com" />
                            </div>
                            <div>
                                <label htmlFor="tags" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Tags (comma-separated)</label>
                                <input type="text" id="tags" value={tags} onChange={e => setTags(e.target.value)} className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white" />
                            </div>
                        </>
                    ) : (
                        <>
                            <div>
                                <label htmlFor="cert-title" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Certificate Title</label>
                                <input type="text" id="cert-title" value={title} onChange={e => setTitle(e.target.value)} className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white" required />
                            </div>
                            <div>
                                <label htmlFor="issuer" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Issuer</label>
                                <input type="text" id="issuer" value={issuer} onChange={e => setIssuer(e.target.value)} className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white" required />
                            </div>
                            <div>
                                <label htmlFor="date" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Date Issued</label>
                                <input type="date" id="date" value={date} onChange={e => setDate(e.target.value)} className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white" required />
                            </div>
                        </>
                    )}

                    <button type="submit" className="w-full text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                        Upload Content
                    </button>
                    {uploadStatus && <p className="text-sm text-center text-gray-600 dark:text-gray-300 mt-4">{uploadStatus}</p>}
                </form>
            </div>
        </div>
    );
};

export default UploadPage;
