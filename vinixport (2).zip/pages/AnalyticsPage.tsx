
import React, { useMemo } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell } from 'recharts';
import { usePortfolio } from '../contexts/PortfolioContext';

const StatCard = ({ title, value, subtext, icon, colorClass }: {title: string, value: string, subtext?: string, icon: React.ReactNode, colorClass: string}) => (
    <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md flex items-center space-x-4 border-l-4 border-transparent hover:border-gray-200 dark:hover:border-gray-700 transition-all h-full">
        <div className={`p-3 rounded-full ${colorClass} text-white`}>
            {icon}
        </div>
        <div>
            <p className="text-sm text-gray-500 dark:text-gray-400 font-medium">{title}</p>
            <p className="text-3xl font-bold text-gray-900 dark:text-white">{value}</p>
            {subtext && <p className="text-xs text-gray-400 dark:text-gray-500 mt-1">{subtext}</p>}
        </div>
    </div>
);

const AnalyticsPage: React.FC = () => {
    const { projects, certificates } = usePortfolio();

    // Data for Chart (Projects vs Certificates)
    const contentData = useMemo(() => [
        { name: 'Projects', count: projects.length, color: '#3B82F6' }, // Blue
        { name: 'Certificates', count: certificates.length, color: '#F59E0B' } // Yellow/Orange
    ], [projects.length, certificates.length]);

    return (
        <div className="container mx-auto p-4 md:p-8">
            <div className="flex justify-between items-center mb-8">
                <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Portfolio Analytics</h1>
                <span className="bg-blue-100 text-blue-800 text-xs font-medium inline-flex items-center px-2.5 py-0.5 rounded dark:bg-blue-900 dark:text-blue-300">
                    <svg className="mr-1 w-3 h-3" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clipRule="evenodd"></path></svg>
                    Live Data
                </span>
            </div>

            {/* Stats Cards Grid - Adjusted to 2 columns */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                
                {/* Card 1: Total Projects */}
                <StatCard 
                    title="Total Projects"
                    value={projects.length.toString()}
                    subtext="Proyek aktif di portofolio"
                    colorClass="bg-blue-600"
                    icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path></svg>}
                />

                {/* Card 2: Total Certificates */}
                <StatCard 
                    title="Total Certificates"
                    value={certificates.length.toString()}
                    subtext="Sertifikat yang telah diunggah"
                    colorClass="bg-yellow-500"
                    icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z"></path></svg>}
                />
            </div>

            {/* Content Distribution Chart */}
            <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
                <h2 className="text-xl font-bold mb-6 text-gray-900 dark:text-white">Content Overview</h2>
                <div className="h-80 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                        <BarChart 
                            data={contentData} 
                            margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                            barSize={60}
                        >
                            <CartesianGrid strokeDasharray="3 3" stroke="#374151" opacity={0.2} vertical={false} />
                            <XAxis 
                                dataKey="name" 
                                stroke="#9CA3AF" 
                                tick={{ fill: '#6B7280' }}
                                axisLine={false}
                                tickLine={false}
                            />
                            <YAxis 
                                stroke="#9CA3AF" 
                                tick={{ fill: '#6B7280' }}
                                axisLine={false}
                                tickLine={false}
                                allowDecimals={false}
                            />
                            <Tooltip 
                                cursor={{ fill: 'transparent' }}
                                contentStyle={{ backgroundColor: '#1F2937', border: 'none', borderRadius: '8px', color: '#fff' }}
                                itemStyle={{ color: '#fff' }}
                            />
                            <Legend verticalAlign="top" height={36}/>
                            <Bar dataKey="count" name="Total Items" radius={[8, 8, 0, 0]}>
                                {contentData.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={entry.color} />
                                ))}
                            </Bar>
                        </BarChart>
                    </ResponsiveContainer>
                </div>
                <p className="text-center text-gray-500 dark:text-gray-400 mt-4 text-sm">
                    Grafik perbandingan jumlah konten Project vs Certificate dalam portofolio Anda.
                </p>
            </div>
        </div>
    );
};

export default AnalyticsPage;
