
import React, { useState, useRef, useEffect, useMemo } from 'react';
import SkillChart from '../components/SkillChart';
import ProjectCard from '../components/ProjectCard';
import CertificateCard from '../components/CertificateCard';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { usePortfolio } from '../contexts/PortfolioContext';
import ProjectEditModal from '../components/ProjectEditModal';
import CertificateEditModal from '../components/CertificateEditModal';
import { Project, Certificate, Skill } from '../types';
import { useAuth } from '../contexts/AuthContext';


const EditIcon = ({ className = "h-5 w-5" }: { className?: string }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 20 20" fill="currentColor">
        <path d="M17.414 2.586a2 2 0 00-2.828 0L7 10.172V13h2.828l7.586-7.586a2 2 0 000-2.828z" />
        <path fillRule="evenodd" d="M2 6a2 2 0 012-2h4a1 1 0 010 2H4v10h10v-4a1 1 0 112 0v4a2 2 0 01-2 2H4a2 2 0 01-2-2V6z" clipRule="evenodd" />
    </svg>
);

interface AnalysisResult {
    category: string;
    score: number;
    feedback: string;
    colorClass: string;
}

const PortfolioPage: React.FC = () => {
    const { user, updateUser } = useAuth();
    
    // Bio Editing State
    const [isEditingBio, setIsEditingBio] = useState(false);
    const [editedBio, setEditedBio] = useState('');
    
    // Title/Profession Editing State
    const [isEditingTitle, setIsEditingTitle] = useState(false);
    const [editedTitle, setEditedTitle] = useState('');

    const avatarInputRef = useRef<HTMLInputElement>(null);
    
    useEffect(() => {
        if (user) {
            setEditedBio(user.bio);
            setEditedTitle(user.title);
        }
    }, [user]);

    const { 
        projects, 
        certificates,
        skills, // Get dynamic skills from context
        updateProject,
        deleteProject,
        updateCertificate,
        deleteCertificate 
    } = usePortfolio();

    const [editingProject, setEditingProject] = useState<Project | null>(null);
    const [editingCertificate, setEditingCertificate] = useState<Certificate | null>(null);

    // Generate Analysis based on Assessment Skills
    const assessmentAnalysis = useMemo(() => {
        const relevantCategories = ['Soft Skills', 'Digital Skills', 'Workplace Readiness'];
        const analysisResults: AnalysisResult[] = [];

        skills.forEach(skill => {
            if (relevantCategories.includes(skill.name)) {
                let feedback = '';
                let colorClass = 'text-gray-600';

                if (skill.name === 'Soft Skills') {
                    if (skill.level >= 80) {
                        feedback = "Anda memiliki kemampuan komunikasi dan interpersonal yang sangat baik. Pertahankan kemampuan ini untuk memimpin tim.";
                        colorClass = "text-green-600 dark:text-green-400";
                    } else if (skill.level >= 60) {
                        feedback = "Kemampuan berinteraksi sudah cukup baik. Tingkatkan lagi kepercayaan diri dalam negosiasi dan penyelesaian konflik.";
                        colorClass = "text-yellow-600 dark:text-yellow-400";
                    } else {
                        feedback = "Perlu pengembangan dalam komunikasi tim. Fokuslah belajar mendengar aktif dan menyampaikan ide dengan lebih terstruktur.";
                        colorClass = "text-red-600 dark:text-red-400";
                    }
                } else if (skill.name === 'Digital Skills') {
                     if (skill.level >= 80) {
                        feedback = "Sangat mahir dalam ekosistem digital. Anda siap bekerja dengan berbagai tools produktivitas modern.";
                        colorClass = "text-green-600 dark:text-green-400";
                    } else if (skill.level >= 60) {
                        feedback = "Cukup familiar dengan teknologi dasar. Cobalah mengeksplorasi software manajemen proyek (seperti Trello/Jira) untuk nilai tambah.";
                        colorClass = "text-yellow-600 dark:text-yellow-400";
                    } else {
                        feedback = "Literasi digital perlu ditingkatkan. Mulailah dengan menguasai penggunaan cloud storage (Google Drive) dan aplikasi kolaborasi online.";
                        colorClass = "text-red-600 dark:text-red-400";
                    }
                } else if (skill.name === 'Workplace Readiness') {
                     if (skill.level >= 80) {
                        feedback = "Mentalitas profesional sangat matang. Anda menunjukkan disiplin tinggi dan inisiatif yang kuat.";
                        colorClass = "text-green-600 dark:text-green-400";
                    } else if (skill.level >= 60) {
                        feedback = "Etos kerja sudah terbentuk. Tingkatkan inisiatif mandiri dan manajemen waktu agar lebih efisien.";
                        colorClass = "text-yellow-600 dark:text-yellow-400";
                    } else {
                        feedback = "Perlu adaptasi dengan budaya kerja profesional. Fokus pada ketepatan waktu dan tanggung jawab terhadap tugas.";
                        colorClass = "text-red-600 dark:text-red-400";
                    }
                }

                analysisResults.push({
                    category: skill.name,
                    score: skill.level,
                    feedback,
                    colorClass
                });
            }
        });

        return analysisResults;
    }, [skills]);

    const toBase64 = (url: string): Promise<string | ArrayBuffer | null> => fetch(url)
        .then(response => response.blob())
        .then(blob => new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onloadend = () => resolve(reader.result);
            reader.onerror = reject;
            reader.readAsDataURL(blob);
        }));

    const handleDownloadPdf = async () => {
        if (!user) return;
        const doc = new jsPDF();
        
        doc.setProperties({
            title: `${user.name}'s Portfolio`,
            author: 'VinixPort',
        });

        // Header with Avatar
        try {
            const avatarBase64 = await toBase64(user.avatarUrl) as string;
            // Ensure the format is one jspdf recognizes (JPEG, PNG)
            const imageFormat = avatarBase64.startsWith('data:image/png') ? 'PNG' : 'JPEG';
            doc.addImage(avatarBase64, imageFormat, 20, 20, 30, 30);
        } catch (error) {
            console.error("Could not add avatar to PDF:", error);
        }
        
        doc.setFontSize(28);
        doc.setFont('helvetica', 'bold');
        doc.text(user.name, 60, 30);
        
        doc.setFontSize(16);
        doc.setFont('helvetica', 'normal');
        doc.setTextColor(80, 80, 80);
        doc.text(user.title, 60, 40);
        doc.setDrawColor(200);
        doc.line(20, 55, 190, 55);

        // Bio
        doc.setFontSize(12);
        doc.setTextColor(40, 40, 40);
        const bioText = doc.splitTextToSize(user.bio, 170);
        doc.text(bioText, 20, 65);
        
        const bioDimensions = doc.getTextDimensions(bioText);
        let currentY = 65 + bioDimensions.h;

        const primaryColor = [13, 71, 161];

        // Skills
        autoTable(doc, {
            startY: currentY + 10,
            head: [['Skills', 'Proficiency']],
            body: skills.map(skill => [skill.name, `${skill.level}%`]),
            theme: 'striped',
            headStyles: { fillColor: primaryColor, fontSize: 14, halign: 'center' },
        });

        let lastY = (doc as any).lastAutoTable.finalY;

        // Projects
        if (projects.length > 0) {
            autoTable(doc, {
                startY: lastY + 10,
                head: [['Project', 'Description']],
                body: projects.map(p => [p.title, p.description]),
                theme: 'grid',
                headStyles: { fillColor: primaryColor, fontSize: 14, halign: 'center' },
            });
            lastY = (doc as any).lastAutoTable.finalY;
        }
        
        // Certificates
        if (certificates.length > 0) {
             autoTable(doc, {
                startY: lastY + 10,
                head: [['Certificate', 'Issuer', 'Date']],
                body: certificates.map(c => [c.title, c.issuer, c.date]),
                theme: 'striped',
                headStyles: { fillColor: primaryColor, fontSize: 14, halign: 'center' },
            });
        }
        
        // Footer
        const pageCount = (doc as any).internal.getNumberOfPages();
        for (let i = 1; i <= pageCount; i++) {
            doc.setPage(i);
            doc.setFontSize(10);
            doc.setTextColor(150);
            doc.text(`Page ${i} of ${pageCount}`, doc.internal.pageSize.getWidth() - 30, doc.internal.pageSize.getHeight() - 10);
            doc.text('Generated by VinixPort', 20, doc.internal.pageSize.getHeight() - 10);
        }

        doc.save(`${user.name.replace(/\s/g, '_')}_Portfolio.pdf`);
    };

    const handleSaveBio = () => {
        updateUser({ bio: editedBio });
        setIsEditingBio(false);
    };

    const handleSaveTitle = () => {
        updateUser({ title: editedTitle });
        setIsEditingTitle(false);
    };
    
    const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            const file = e.target.files[0];
            
            // Convert to Base64 for persistence in LocalStorage
            const reader = new FileReader();
            reader.onloadend = () => {
                const base64String = reader.result as string;
                updateUser({ avatarUrl: base64String });
            };
            reader.readAsDataURL(file);
        }
    };

    const triggerAvatarUpload = () => {
        avatarInputRef.current?.click();
    };

    if (!user) {
        return (
            <div className="container mx-auto p-8 text-center">
                <p>Loading portfolio...</p>
            </div>
        );
    }

    return (
        <>
            <div className="container mx-auto p-4 md:p-8">
                <div className="bg-white dark:bg-gray-800 shadow-xl rounded-lg overflow-hidden">
                    {/* Header */}
                    <div className="bg-gradient-to-r from-blue-600 to-cyan-500 p-8">
                        <div className="flex flex-col md:flex-row items-center space-y-4 md:space-y-0 md:space-x-6">
                            <div className="relative group">
                                <img className="w-32 h-32 rounded-full border-4 border-white shadow-lg object-cover" src={user.avatarUrl} alt={user.name} />
                                <button 
                                    onClick={triggerAvatarUpload}
                                    className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-50 flex items-center justify-center rounded-full transition-opacity duration-300 opacity-0 group-hover:opacity-100"
                                    aria-label="Change profile picture"
                                >
                                    <EditIcon className="w-8 h-8 text-white" />
                                </button>
                                <input 
                                    type="file" 
                                    ref={avatarInputRef} 
                                    onChange={handleAvatarChange} 
                                    className="hidden" 
                                    accept="image/png, image/jpeg" 
                                />
                            </div>
                            <div className="flex-1">
                                <h1 className="text-3xl font-bold text-white">{user.name}</h1>
                                
                                {isEditingTitle ? (
                                    <div className="mt-2 flex flex-wrap items-center gap-2">
                                        <input
                                            type="text"
                                            value={editedTitle}
                                            onChange={(e) => setEditedTitle(e.target.value)}
                                            className="text-gray-900 text-lg rounded px-3 py-1 outline-none border-none w-full md:w-auto min-w-[250px]"
                                            placeholder="Enter your profession"
                                            autoFocus
                                        />
                                        <button onClick={handleSaveTitle} className="bg-white text-blue-600 px-3 py-1 rounded text-sm font-bold hover:bg-gray-100">Save</button>
                                        <button onClick={() => {
                                            setIsEditingTitle(false);
                                            setEditedTitle(user.title);
                                        }} className="text-white hover:text-gray-200 text-sm border border-white/30 px-3 py-1 rounded">Cancel</button>
                                    </div>
                                ) : (
                                    <div className="flex items-center space-x-2 group mt-1">
                                        <p className="text-blue-100 text-lg">{user.title}</p>
                                        <button 
                                            onClick={() => setIsEditingTitle(true)}
                                            className="opacity-0 group-hover:opacity-100 transition-opacity text-blue-200 hover:text-white p-1 rounded hover:bg-white/10"
                                            aria-label="Edit Title"
                                        >
                                            <EditIcon className="h-4 w-4" />
                                        </button>
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>

                    {/* Main Content */}
                    <div className="p-8 grid grid-cols-1 lg:grid-cols-3 gap-8">
                        {/* Left Column (Bio & Actions) */}
                        <div className="lg:col-span-1 space-y-8">
                            <div className="bg-gray-50 dark:bg-gray-700 p-6 rounded-lg">
                                <div className="flex justify-between items-center mb-4">
                                    <h2 className="text-xl font-bold text-gray-900 dark:text-white">About Me</h2>
                                    {!isEditingBio && (
                                        <button onClick={() => setIsEditingBio(true)} className="text-gray-500 hover:text-blue-600 dark:text-gray-400 dark:hover:text-blue-400" aria-label="Edit Bio">
                                            <EditIcon />
                                        </button>
                                    )}
                                </div>
                                {isEditingBio ? (
                                    <div>
                                        <textarea
                                            value={editedBio}
                                            onChange={(e) => setEditedBio(e.target.value)}
                                            rows={6}
                                            className="block p-2.5 w-full text-sm text-gray-900 bg-white rounded-lg border border-gray-300 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-800 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white"
                                            aria-label="Bio editor"
                                        />
                                        <div className="flex justify-end space-x-2 mt-2">
                                            <button onClick={() => {
                                                setIsEditingBio(false);
                                                setEditedBio(user.bio);
                                            }} className="text-gray-600 dark:text-gray-300 px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-200 dark:hover:bg-gray-600">Cancel</button>
                                            <button onClick={handleSaveBio} className="text-white bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg text-sm font-medium">Save</button>
                                        </div>
                                    </div>
                                ) : (
                                    <p className="text-gray-600 dark:text-gray-300 whitespace-pre-line">{user.bio}</p>
                                )}
                            </div>
                            <div className="bg-gray-50 dark:bg-gray-700 p-6 rounded-lg">
                                <h2 className="text-xl font-bold mb-4 text-gray-900 dark:text-white">Actions</h2>
                                <div className="flex flex-col space-y-3">
                                    <button onClick={handleDownloadPdf} className="w-full text-white bg-green-600 hover:bg-green-700 font-medium rounded-lg text-sm px-5 py-2.5 text-center transition">Download as PDF</button>
                                </div>
                            </div>
                        </div>
                        
                        {/* Right Column (Skills, Projects, Certs) */}
                        <div className="lg:col-span-2 space-y-8">
                            <section>
                                <h2 className="text-2xl font-bold mb-4 text-gray-900 dark:text-white">Skills</h2>
                                <div className="bg-gray-50 dark:bg-gray-700 p-6 rounded-lg">
                                    <SkillChart data={skills} />

                                    {/* Persiapan Dunia Kerja Section */}
                                    <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-600">
                                        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Persiapan Dunia Kerja & Pengembangan Diri</h3>
                                        
                                        {assessmentAnalysis.length > 0 ? (
                                            <div className="space-y-4">
                                                <p className="text-gray-600 dark:text-gray-300 text-sm mb-2">
                                                    Berdasarkan hasil asesmen Anda, berikut adalah area kekuatan dan saran pengembangan untuk kesiapan karir:
                                                </p>
                                                <ul className="space-y-4">
                                                    {assessmentAnalysis.map((item) => (
                                                        <li key={item.category} className="bg-white dark:bg-gray-800 p-4 rounded-lg border-l-4 border-blue-500 shadow-sm">
                                                            <div className="flex justify-between items-center mb-1">
                                                                <h4 className="font-bold text-gray-800 dark:text-gray-200">{item.category}</h4>
                                                                <span className={`text-sm font-bold ${
                                                                    item.score >= 80 ? 'text-green-600' : item.score >= 60 ? 'text-yellow-600' : 'text-red-600'
                                                                }`}>{item.score >= 80 ? 'High' : item.score >= 60 ? 'Medium' : 'Low'} ({item.score}%)</span>
                                                            </div>
                                                            <p className={`text-sm ${item.colorClass}`}>
                                                                {item.feedback}
                                                            </p>
                                                        </li>
                                                    ))}
                                                </ul>
                                            </div>
                                        ) : (
                                            <div className="bg-blue-50 dark:bg-blue-900/30 p-4 rounded-lg">
                                                <p className="text-gray-600 dark:text-gray-300 text-sm">
                                                    Anda belum menyelesaikan Skill Assessment. Selesaikan asesmen untuk mendapatkan analisis mendalam tentang kesiapan kerja Anda (Soft Skills, Digital Skills, & Readiness).
                                                </p>
                                            </div>
                                        )}
                                    </div>
                                </div>
                            </section>

                            <section>
                                <h2 className="text-2xl font-bold mb-4 text-gray-900 dark:text-white">Projects</h2>
                                {projects.length === 0 ? (
                                    <div className="bg-gray-50 dark:bg-gray-700 p-8 rounded-lg text-center">
                                        <p className="text-gray-500 dark:text-gray-400 italic">Belum ada proyek yang ditambahkan.</p>
                                        <p className="text-sm text-gray-400 dark:text-gray-500 mt-2">Gunakan menu "Upload" untuk menambahkan proyek Anda.</p>
                                    </div>
                                ) : (
                                    <div className="grid md:grid-cols-2 gap-6">
                                        {projects.map(project => <ProjectCard key={project.id} project={project} onEdit={() => setEditingProject(project)} onDelete={() => deleteProject(project.id)} />)}
                                    </div>
                                )}
                            </section>

                            <section>
                                <h2 className="text-2xl font-bold mb-4 text-gray-900 dark:text-white">Certificates</h2>
                                {certificates.length === 0 ? (
                                    <div className="bg-gray-50 dark:bg-gray-700 p-8 rounded-lg text-center">
                                        <p className="text-gray-500 dark:text-gray-400 italic">Belum ada sertifikat yang ditambahkan.</p>
                                    </div>
                                ) : (
                                    <div className="space-y-4">
                                        {certificates.map(cert => (
                                            <CertificateCard key={cert.id} certificate={cert} onEdit={() => setEditingCertificate(cert)} onDelete={() => deleteCertificate(cert.id)} />
                                        ))}
                                    </div>
                                )}
                            </section>
                        </div>
                    </div>
                </div>
            </div>

            <ProjectEditModal
                project={editingProject}
                onClose={() => setEditingProject(null)}
                onSave={(updated) => {
                    updateProject(updated);
                }}
            />
            <CertificateEditModal
                certificate={editingCertificate}
                onClose={() => setEditingCertificate(null)}
                onSave={(updated) => {
                    updateCertificate(updated);
                }}
            />
        </>
    );
};

export default PortfolioPage;
