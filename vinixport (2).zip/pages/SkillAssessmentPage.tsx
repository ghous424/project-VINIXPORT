
import React, { useState } from 'react';
import { mockAssessmentQuestions } from '../services/mockData';
import SkillChart from '../components/SkillChart';
import { Skill } from '../types';
import { usePortfolio } from '../contexts/PortfolioContext';
import { useNavigate } from 'react-router-dom';

const SkillAssessmentPage: React.FC = () => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  // Store answers as questionId: score (1-5)
  const [answers, setAnswers] = useState<{[key: number]: number}>({});
  const [showResults, setShowResults] = useState(false);
  const [calculatedSkills, setCalculatedSkills] = useState<Skill[]>([]);
  
  const { updateSkills } = usePortfolio();
  const navigate = useNavigate();

  const questions = mockAssessmentQuestions;
  const currentQuestion = questions[currentQuestionIndex];
  const progress = ((currentQuestionIndex) / questions.length) * 100;

  const handleLikertSelect = (score: number) => {
    const newAnswers = {
      ...answers,
      [currentQuestion.id]: score
    };
    setAnswers(newAnswers);

    // Auto advance after a short delay for better UX
    setTimeout(() => {
        if (currentQuestionIndex < questions.length - 1) {
            setCurrentQuestionIndex(currentQuestionIndex + 1);
        } else {
            finishAssessment(newAnswers);
        }
    }, 250);
  };

  const finishAssessment = (finalAnswers: {[key: number]: number}) => {
      // Calculate scores per category
      const categories = ['Soft Skills', 'Digital Skills', 'Workplace Readiness'];
      const results: Skill[] = categories.map(category => {
          const categoryQuestions = questions.filter(q => q.category === category);
          const totalQuestions = categoryQuestions.length;
          
          // Sum scores for this category
          const totalScore = categoryQuestions.reduce((sum, q) => {
              return sum + (finalAnswers[q.id] || 0);
          }, 0);

          // Max possible score is 5 * number of questions
          const maxScore = totalQuestions * 5;
          
          // Convert to 0-100 scale
          const percentage = Math.round((totalScore / maxScore) * 100);

          return { name: category, level: percentage };
      });

      setCalculatedSkills(results);
      
      // Update Global Context so Portfolio Page reflects these new skills
      updateSkills(results);
      
      setShowResults(true);
  };

  if (showResults) {
    return (
        <div className="container mx-auto p-4 md:p-8">
            <div className="bg-white dark:bg-gray-800 shadow-xl rounded-lg p-6 md:p-10 max-w-2xl mx-auto text-center">
                <h1 className="text-3xl font-bold mb-4 text-gray-900 dark:text-white">Assessment Complete!</h1>
                <p className="text-lg mb-6 text-gray-600 dark:text-gray-300">
                   Terima kasih telah menyelesaikan asesmen. Berikut adalah peta kekuatan profesional Anda berdasarkan asesmen mandiri.
                </p>
                
                <div className="mb-8 bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                    <SkillChart data={calculatedSkills} />
                </div>

                <div className="grid gap-4 text-left">
                    {calculatedSkills.map((skill) => (
                        <div key={skill.name} className="bg-gray-50 dark:bg-gray-700 p-4 rounded border-l-4 border-blue-500">
                            <div className="flex justify-between items-center mb-1">
                                <span className="font-bold text-gray-900 dark:text-white">{skill.name}</span>
                                <span className="text-blue-600 dark:text-blue-400 font-bold">{skill.level}%</span>
                            </div>
                            <div className="w-full bg-gray-200 dark:bg-gray-600 rounded-full h-2.5">
                                <div className="bg-blue-600 h-2.5 rounded-full transition-all duration-1000" style={{ width: `${skill.level}%` }}></div>
                            </div>
                        </div>
                    ))}
                </div>

                <div className="flex flex-col md:flex-row gap-4 mt-8">
                    <button
                        onClick={() => {
                            setShowResults(false);
                            setCurrentQuestionIndex(0);
                            setAnswers({});
                        }}
                        className="flex-1 bg-gray-200 text-gray-800 font-bold py-3 px-6 rounded-lg hover:bg-gray-300 transition duration-300"
                    >
                        Retake Assessment
                    </button>
                    <button
                        onClick={() => navigate('/portfolio')}
                        className="flex-1 bg-blue-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-blue-700 transition duration-300"
                    >
                        Go to My Portfolio
                    </button>
                </div>
            </div>
        </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-gray-800 shadow-2xl rounded-lg w-full max-w-2xl p-6 md:p-8">
        <div className="flex justify-between items-end mb-4">
            <div>
                <h1 className="text-2xl md:text-3xl font-bold text-gray-900 dark:text-white">Self Assessment</h1>
                <span className="inline-block bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded mt-2 dark:bg-blue-900 dark:text-blue-300">
                    {currentQuestion.category}
                </span>
            </div>
            <span className="text-gray-500 dark:text-gray-400 text-sm">
                {currentQuestionIndex + 1} / {questions.length}
            </span>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5 mb-8">
          <div className="bg-blue-600 h-2.5 rounded-full transition-all duration-300" style={{ width: `${progress}%` }}></div>
        </div>

        {/* Question */}
        <div className="mb-10 text-center">
          <p className="text-xl md:text-2xl font-medium text-gray-800 dark:text-gray-200 leading-relaxed">
            "{currentQuestion.question}"
          </p>
        </div>

        {/* Likert Scale Options */}
        <div className="space-y-4">
            <div className="flex justify-between text-xs md:text-sm text-gray-500 dark:text-gray-400 px-1 mb-2">
                <span>Sangat Tidak Bisa</span>
                <span>Sangat Bisa</span>
            </div>
            <div className="flex justify-between gap-2">
                {[1, 2, 3, 4, 5].map((val) => (
                    <button
                        key={val}
                        onClick={() => handleLikertSelect(val)}
                        className={`flex-1 aspect-square md:aspect-auto md:h-14 rounded-lg border-2 flex items-center justify-center text-lg font-bold transition-all duration-200
                        ${answers[currentQuestion.id] === val 
                            ? 'bg-blue-600 border-blue-600 text-white shadow-lg scale-105' 
                            : 'bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 text-gray-600 dark:text-gray-300 hover:border-blue-400 hover:bg-blue-50 dark:hover:bg-gray-600'
                        }`}
                    >
                        {val}
                    </button>
                ))}
            </div>
        </div>
        
        <div className="mt-8 flex justify-between">
             <button
                onClick={() => setCurrentQuestionIndex(Math.max(0, currentQuestionIndex - 1))}
                disabled={currentQuestionIndex === 0}
                className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 disabled:opacity-50"
             >
                 &larr; Previous
             </button>
             
             {/* Placeholder to balance flex layout */}
             <div className="w-10"></div> 
        </div>
      </div>
    </div>
  );
};

export default SkillAssessmentPage;
