
import React from 'react';
import { Link } from 'react-router-dom';

const FeatureCard = ({ icon, title, description }: { icon: React.ReactNode, title: string, description: string }) => (
  <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md text-center">
    <div className="flex justify-center items-center mb-4 w-12 h-12 rounded-full bg-blue-100 dark:bg-blue-900 mx-auto">
      {icon}
    </div>
    <h3 className="mb-2 text-xl font-bold dark:text-white">{title}</h3>
    <p className="text-gray-500 dark:text-gray-400">{description}</p>
  </div>
);

const AlumniCard = ({ name, title, imageUrl }: { name: string, title: string, imageUrl: string }) => (
    <div className="text-center text-gray-500 dark:text-gray-400">
        <img className="mx-auto mb-4 w-36 h-36 rounded-full object-cover" src={imageUrl} alt={`${name} Avatar`} />
        <h3 className="mb-1 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">
            <a href="#">{name}</a>
        </h3>
        <p>{title}</p>
    </div>
);

const LandingPage: React.FC = () => {
  return (
    <>
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-700 via-blue-800 to-gray-900 text-white">
        <div className="container mx-auto px-4 py-24 text-center">
          <h1 className="text-4xl md:text-6xl font-extrabold mb-4">Ubah Hasil Pelatihanmu Jadi Portofolio Profesional</h1>
          <p className="text-lg md:text-xl mb-8 max-w-2xl mx-auto text-gray-300">
            Dengan VinixPort, tampilkan keahlian dan proyek terbaikmu dalam portofolio yang menarik dan mudah dibagikan.
          </p>
          <Link
            to="/register"
            className="bg-white text-blue-800 font-bold rounded-full py-4 px-8 shadow-lg uppercase tracking-wider hover:bg-gray-200 transition duration-300"
          >
            Buat Portofolio Gratis
          </Link>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50 dark:bg-gray-900">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-12 text-gray-900 dark:text-white">Fitur Unggulan</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <FeatureCard 
              icon={<svg className="w-6 h-6 text-blue-600 dark:text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01"></path></svg>}
              title="Skill Assessment"
              description="Uji dan validasi keahlianmu dengan asesmen terstandarisasi untuk meningkatkan kredibilitas."
            />
            <FeatureCard 
              icon={<svg className="w-6 h-6 text-blue-600 dark:text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"></path></svg>}
              title="Upload Konten Mudah"
              description="Drag & drop proyek, sertifikat, dan bukti keahlian lainnya dengan mudah dan cepat."
            />
            <FeatureCard 
              icon={<svg className="w-6 h-6 text-blue-600 dark:text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"></path></svg>}
              title="Analitik Performa"
              description="Pantau siapa yang melihat portofoliomu dan bagaimana performa setiap proyek yang kamu tampilkan."
            />
            <FeatureCard 
              icon={<svg className="w-6 h-6 text-blue-600 dark:text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>}
              title="Ekspor ke PDF"
              description="Unduh portofolio lengkapmu dalam format PDF profesional untuk dibagikan secara offline."
            />
          </div>
        </div>
      </section>

      {/* Alumni Preview Section */}
      <section className="bg-white dark:bg-gray-800">
        <div className="py-8 px-4 mx-auto max-w-screen-xl text-center lg:py-16 lg:px-6">
            <div className="mx-auto mb-8 max-w-screen-sm lg:mb-16">
                <h2 className="mb-4 text-4xl tracking-tight font-extrabold text-gray-900 dark:text-white">Portofolio Alumni Terbaik</h2>
                <p className="font-light text-gray-500 sm:text-xl dark:text-gray-400">Lihat bagaimana para profesional seperti Anda telah sukses membangun karir dengan portofolio dari VinixPort.</p>
            </div> 
            <div className="grid gap-8 lg:gap-16 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
                <AlumniCard name="Bonnie Green" title="Web Developer" imageUrl="https://picsum.photos/seed/alumni1/200/200" />
                <AlumniCard name="Jese Leos" title="UI/UX Designer" imageUrl="https://picsum.photos/seed/alumni2/200/200" />
                <AlumniCard name="Michael Gough" title="Data Scientist" imageUrl="https://picsum.photos/seed/alumni3/200/200" />
                <AlumniCard name="Lana Byrd" title="Mobile App Developer" imageUrl="https://picsum.photos/seed/alumni4/200/200" />
            </div>
        </div>
      </section>
    </>
  );
};

export default LandingPage;
