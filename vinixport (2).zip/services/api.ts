
import { User, Project, Certificate } from '../types';
import { mockUser, mockProjects, mockCertificates } from './mockData';

// --- KONFIGURASI ---
// Ubah ke TRUE jika server backend (backend/server.js) sudah berjalan.
// Ubah ke FALSE untuk menggunakan data dummy (Mode Preview) dengan LocalStorage Persistence.
const USE_BACKEND = false; 
const API_URL = 'http://localhost:5000/api';

// --- LOCAL STORAGE KEYS (Untuk Mode Mock) ---
const KEYS = {
    USER: 'vinix_user',
    PROJECTS: 'vinix_projects',
    CERTS: 'vinix_certificates'
};

// Helper untuk Mock Storage
const getStorage = <T>(key: string, defaultValue: T): T => {
    const stored = localStorage.getItem(key);
    if (stored) {
        return JSON.parse(stored);
    }
    // Inisialisasi jika kosong
    localStorage.setItem(key, JSON.stringify(defaultValue));
    return defaultValue;
};

const setStorage = (key: string, data: any) => {
    localStorage.setItem(key, JSON.stringify(data));
};

// Helper untuk request Backend Asli
const request = async (endpoint: string, options?: RequestInit) => {
    try {
        const res = await fetch(`${API_URL}${endpoint}`, {
            headers: { 'Content-Type': 'application/json' },
            ...options,
        });
        if (!res.ok) {
            const errorData = await res.json();
            throw new Error(errorData.message || 'API Error');
        }
        return await res.json();
    } catch (err) {
        console.error(`API Request Failed: ${endpoint}`, err);
        throw err;
    }
};

export const api = {
    // --- AUTH ---
    login: async (email: string, password: string) => {
        if (!USE_BACKEND) {
            // Mock Logic dengan Persistence
            return new Promise<{user: User}>((resolve, reject) => {
                setTimeout(() => {
                    // Ambil user dari storage (atau default mockUser jika belum ada)
                    const currentUser = getStorage<User>(KEYS.USER, { ...mockUser });
                    
                    // Simple check (Di real app check hash password)
                    // Kita perbolehkan login demo atau jika email match dengan yang tersimpan
                    if ((email === 'alex.doe@example.com' && password === 'password123') || email === currentUser.email) {
                        resolve({ user: currentUser });
                    } else {
                        reject(new Error('Invalid credentials (Mock)'));
                    }
                }, 800);
            });
        }
        return request('/login', {
            method: 'POST',
            body: JSON.stringify({ email, password }),
        });
    },

    register: async (name: string, email: string, password: string) => {
        if (!USE_BACKEND) {
            return new Promise<void>((resolve) => {
                // Simpan user baru ke storage
                const newUser: User = {
                    name,
                    email,
                    title: 'New Member',
                    bio: 'Tell us about yourself...',
                    avatarUrl: 'https://ui-avatars.com/api/?name=' + name.replace(' ', '+')
                };
                setStorage(KEYS.USER, newUser);
                setTimeout(resolve, 800);
            });
        }
        return request('/register', {
            method: 'POST',
            body: JSON.stringify({ name, email, password }),
        });
    },

    updateProfile: async (userId: number, data: Partial<User>) => {
        if(!USE_BACKEND) {
            return new Promise<void>((resolve) => {
                const currentUser = getStorage<User>(KEYS.USER, { ...mockUser });
                const updatedUser = { ...currentUser, ...data };
                setStorage(KEYS.USER, updatedUser);
                resolve();
            });
        }
        
        return request(`/users/${userId || 1}`, {
            method: 'PUT',
            body: JSON.stringify(data)
        });
    },

    // --- PORTFOLIO DATA ---
    getPortfolio: async (userId: number) => {
        if (!USE_BACKEND) {
            return new Promise<{ projects: Project[], certificates: Certificate[] }>((resolve) => {
                setTimeout(() => {
                    const projects = getStorage<Project[]>(KEYS.PROJECTS, mockProjects);
                    const certificates = getStorage<Certificate[]>(KEYS.CERTS, mockCertificates);
                    resolve({ projects, certificates });
                }, 500);
            });
        }
        return request(`/portfolio/${userId}`);
    },

    addProject: async (userId: number, project: Omit<Project, 'id'>) => {
        if (!USE_BACKEND) {
            return new Promise<Project>((resolve) => {
                const projects = getStorage<Project[]>(KEYS.PROJECTS, mockProjects);
                const newProject = { ...project, id: Date.now() };
                const updatedProjects = [newProject, ...projects];
                setStorage(KEYS.PROJECTS, updatedProjects);
                resolve(newProject);
            });
        }
        return request('/projects', {
            method: 'POST',
            body: JSON.stringify({ userId, ...project }),
        });
    },

    updateProject: async (project: Project) => {
        if(!USE_BACKEND) {
            const projects = getStorage<Project[]>(KEYS.PROJECTS, mockProjects);
            const updatedProjects = projects.map(p => p.id === project.id ? project : p);
            setStorage(KEYS.PROJECTS, updatedProjects);
            return;
        }
        // Implement real backend update if needed
    },

    deleteProject: async (id: number) => {
        if (!USE_BACKEND) {
             const projects = getStorage<Project[]>(KEYS.PROJECTS, mockProjects);
             const updatedProjects = projects.filter(p => p.id !== id);
             setStorage(KEYS.PROJECTS, updatedProjects);
             return;
        }
        return request(`/projects/${id}`, { method: 'DELETE' });
    },

    addCertificate: async (userId: number, cert: Omit<Certificate, 'id'>) => {
        if (!USE_BACKEND) {
             return new Promise<Certificate>((resolve) => {
                const certs = getStorage<Certificate[]>(KEYS.CERTS, mockCertificates);
                const newCert = { ...cert, id: Date.now() };
                const updatedCerts = [newCert, ...certs];
                setStorage(KEYS.CERTS, updatedCerts);
                resolve(newCert);
            });
        }
        return request('/certificates', {
            method: 'POST',
            body: JSON.stringify({ userId, ...cert }),
        });
    },

    updateCertificate: async (cert: Certificate) => {
        if(!USE_BACKEND) {
            const certs = getStorage<Certificate[]>(KEYS.CERTS, mockCertificates);
            const updatedCerts = certs.map(c => c.id === cert.id ? cert : c);
            setStorage(KEYS.CERTS, updatedCerts);
            return;
        }
    },

    deleteCertificate: async (id: number) => {
        if (!USE_BACKEND) {
            const certs = getStorage<Certificate[]>(KEYS.CERTS, mockCertificates);
            const updatedCerts = certs.filter(c => c.id !== id);
            setStorage(KEYS.CERTS, updatedCerts);
            return;
        }
        return request(`/certificates/${id}`, { method: 'DELETE' });
    }
};
