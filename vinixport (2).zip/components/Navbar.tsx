
import React, { useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

const LogoIcon = () => (
  <svg width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-white">
    <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M2 17L12 22L22 17" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M2 12L12 17L22 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);


const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const { isAuthenticated, user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    setIsOpen(false);
    navigate('/');
  };

  const navLinkClass = ({ isActive }: { isActive: boolean }) =>
    `block py-2 pr-4 pl-3 rounded md:p-0 ${
      isActive
        ? 'text-white bg-blue-700 md:bg-transparent md:text-blue-500'
        : 'text-gray-400 hover:bg-gray-700 hover:text-white md:hover:bg-transparent md:hover:text-blue-500'
    }`;

  return (
    <nav className="bg-gray-800 border-gray-700 px-2 sm:px-4 py-2.5 sticky top-0 z-50">
      <div className="container flex flex-wrap justify-between items-center mx-auto">
        {/* Redirect to Portfolio if logged in, otherwise Home */}
        <Link to={isAuthenticated ? "/portfolio" : "/"} className="flex items-center">
          <LogoIcon />
          <span className="self-center text-xl font-semibold whitespace-nowrap text-white ml-2">VinixPort</span>
        </Link>
        <div className="flex items-center md:order-2">
          {/* Auth buttons for medium screens and up */}
          <div className="hidden md:flex items-center space-x-2">
            {isAuthenticated ? (
              <>
                <span className="text-white mr-4">Hi, {user?.name.split(' ')[0]}</span>
                <button onClick={handleLogout} className="text-white bg-red-600 hover:bg-red-700 focus:ring-4 focus:ring-red-800 font-medium rounded-lg text-sm px-5 py-2.5 text-center">
                  Logout
                </button>
              </>
            ) : (
              <>
                <Link to="/login" className="text-white bg-blue-600 hover:bg-blue-700 focus:ring-4 focus:ring-blue-800 font-medium rounded-lg text-sm px-5 py-2.5 text-center">
                  Login
                </Link>
                <Link to="/register" className="text-white bg-gray-600 hover:bg-gray-700 focus:ring-4 focus:ring-gray-800 font-medium rounded-lg text-sm px-5 py-2.5 text-center">
                  Register
                </Link>
              </>
            )}
          </div>
          {/* Hamburger menu button for small screens */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            type="button"
            className="inline-flex items-center p-2 ml-3 text-sm text-gray-400 rounded-lg md:hidden hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-600"
            aria-controls="mobile-menu"
            aria-expanded={isOpen}
          >
            <span className="sr-only">Open main menu</span>
            <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fillRule="evenodd" d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 15a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clipRule="evenodd"></path></svg>
          </button>
        </div>
        <div className={`${isOpen ? 'block' : 'hidden'} justify-between items-center w-full md:flex md:w-auto md:order-1`} id="mobile-menu">
          <ul className="flex flex-col mt-4 md:flex-row md:space-x-8 md:mt-0 md:text-sm md:font-medium">
            {/* Only show Home if NOT authenticated */}
            {!isAuthenticated && (
              <li><NavLink to="/" onClick={() => setIsOpen(false)} className={navLinkClass} end>Home</NavLink></li>
            )}
            
            {isAuthenticated && (
              <>
                <li><NavLink to="/assessment" onClick={() => setIsOpen(false)} className={navLinkClass}>Skill Assessment</NavLink></li>
                <li><NavLink to="/portfolio" onClick={() => setIsOpen(false)} className={navLinkClass}>My Portfolio</NavLink></li>
                <li><NavLink to="/upload" onClick={() => setIsOpen(false)} className={navLinkClass}>Upload</NavLink></li>
                <li><NavLink to="/analytics" onClick={() => setIsOpen(false)} className={navLinkClass}>Analytics</NavLink></li>
              </>
            )}
            {/* Auth links for mobile view */}
            <li className="mt-4 pt-4 border-t border-gray-700 md:hidden">
            {isAuthenticated ? (
                <button onClick={handleLogout} className="block w-full text-left py-2 pr-4 pl-3 rounded text-gray-400 hover:bg-gray-700 hover:text-white">Logout</button>
            ) : (
                <Link to="/login" onClick={() => setIsOpen(false)} className="block py-2 pr-4 pl-3 rounded text-gray-400 hover:bg-gray-700 hover:text-white">Login</Link>
            )}
            </li>
            {!isAuthenticated && (
              <li className="md:hidden">
                <Link to="/register" onClick={() => setIsOpen(false)} className="block py-2 pr-4 pl-3 rounded text-gray-400 hover:bg-gray-700 hover:text-white">Register</Link>
              </li>
            )}
          </ul>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
