
export interface User {
  name: string;
  email: string;
  avatarUrl: string;
  title: string;
  bio: string;
}

export interface Skill {
  name: string;
  level: number; // 0-100
}

export interface Project {
  id: number;
  title: string;
  description: string;
  imageUrl: string;
  link: string;
  tags: string[];
}

export interface Certificate {
  id: number;
  title: string;
  issuer: string;
  date: string;
  imageUrl: string;
}

export interface AssessmentQuestion {
  id: number;
  category: 'Soft Skills' | 'Digital Skills' | 'Workplace Readiness';
  question: string;
}

export interface AnalyticsData {
  profileViews: { date: string; views: number }[];
  projectClicks: { name: string; clicks: number }[];
  skillDistribution: { name: string; value: number }[];
}
